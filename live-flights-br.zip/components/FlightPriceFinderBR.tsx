
"use client";

import React, { useMemo, useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Plane, Calendar, ArrowRight, Luggage, Settings, MapPin, Shuffle, Clock, Filter, Hash } from "lucide-react";

const Card = ({ children, className = "" }) => (
  <div className={`rounded-2xl shadow-sm border border-gray-200 bg-white ${className}`}>{children}</div>
);
const CardHeader = ({ children, className = "" }) => (
  <div className={`p-4 sm:p-5 border-b border-gray-100 ${className}`}>{children}</div>
);
const CardContent = ({ children, className = "" }) => (
  <div className={`p-4 sm:p-5 ${className}`}>{children}</div>
);
const Button = ({ children, className = "", ...props }: any) => (
  <button
    className={`inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2 font-medium shadow-sm border border-gray-200 hover:shadow transition ${className}`}
    {...props}
  >
    {children}
  </button>
);
const Input = (props: any) => (
  <input {...props} className={`w-full rounded-xl border border-gray-300 px-3 py-2 focus:outline-none focus:ring focus:ring-blue-200 ${props.className || ''}`} />
);
const Select = ({ options, value, onChange, className = "" }: any) => (
  <select
    value={value}
    onChange={onChange}
    className={`w-full rounded-xl border border-gray-300 px-3 py-2 bg-white focus:outline-none focus:ring focus:ring-blue-200 ${className}`}
  >
    {options.map((o: any) => (
      <option key={o.value} value={o.value}>{o.label}</option>
    ))}
  </select>
);

const BR_AIRPORTS = [
  { code: "GRU", city: "São Paulo" },
  { code: "GIG", city: "Rio de Janeiro" },
  { code: "BSB", city: "Brasília" },
  { code: "SSA", city: "Salvador" },
  { code: "REC", city: "Recife" },
  { code: "FOR", city: "Fortaleza" },
  { code: "POA", city: "Porto Alegre" },
  { code: "CWB", city: "Curitiba" },
  { code: "BEL", city: "Belém" },
  { code: "CNF", city: "Belo Horizonte" },
];
const POP_DESTS = [
  { code: "LIS", city: "Lisboa" },
  { code: "MAD", city: "Madrid" },
  { code: "BCN", city: "Barcelona" },
  { code: "MIA", city: "Miami" },
  { code: "JFK", city: "Nova York" },
  { code: "CDG", city: "Paris" },
  { code: "EZE", city: "Buenos Aires" },
  { code: "SCL", city: "Santiago" },
  { code: "MEX", city: "Cidade do México" },
  { code: "NRT", city: "Tóquio" },
];
const CABINS = [
  { value: "economy", label: "Econômica" },
  { value: "premium_economy", label: "Econômica Premium" },
  { value: "business", label: "Executiva" },
  { value: "first", label: "Primeira" },
];

function formatBRL(n: number) {
  try { return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(n); } catch { return `R$ ${n.toFixed(2)}`; }
}
function addDays(date: string, days: number) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0,10);
}

function generateMockOffers({ origin, destination, date, adults, cabin } : any) {
  const seed = (origin + destination + date + adults + cabin).split('').reduce((a:number,c:string)=>a + c.charCodeAt(0), 0);
  function seededRand(i:number){ const x = Math.sin(seed + i) * 10000; return x - Math.floor(x); }
  const carriers = ["LA","G3","AD","TP","AA","DL","AF","IB","TK","CM"];
  const offers = Array.from({ length: 12 }).map((_, i) => {
    const priceBase = 600 + Math.floor(seededRand(i) * 3500);
    const cabinMult = cabin === 'business' ? 2.8 : cabin === 'first' ? 4.2 : cabin === 'premium_economy' ? 1.5 : 1;
    const total = Math.round(priceBase * cabinMult * (adults || 1));
    const legs = Math.floor(seededRand(i+5) * 3);
    const durationHrs = 6 + Math.floor(seededRand(i+7) * 20) + legs*2;
    const dep = new Date(date + 'T22:00:00Z');
    const segs = Array.from({ length: legs + 1 }).map((__, sidx) => ({
      carrier: carriers[(i+sidx)%carriers.length],
      flight: String(100 + (i*3 + sidx)),
      from: sidx === 0 ? origin : `X${sidx}`,
      to: sidx === legs ? destination : `X${sidx+1}`,
      dep: new Date(dep.getTime() + sidx* (durationHrs/(legs+1)) * 3600 * 1000).toISOString(),
      arr: new Date(dep.getTime() + (sidx+1)* (durationHrs/(legs+1)) * 3600 * 1000).toISOString(),
    }));
    const bagIncluded = seededRand(i+99) > 0.5;
    return { id: `MOCK-${i}`, total, currency: "BRL", bagIncluded, itineraries: [{ durationHrs, segments: segs }] };
  });
  return offers.sort((a:any,b:any)=> a.total - b.total || a.itineraries[0].durationHrs - b.itineraries[0].durationHrs);
}

export default function FlightPriceFinderBR() {
  const today = new Date().toISOString().slice(0,10);
  const [origin, setOrigin] = useState("SSA");
  const [destination, setDestination] = useState("LIS");
  const [anywhere, setAnywhere] = useState(false);
  const [date, setDate] = useState(addDays(today, 30));
  const [adults, setAdults] = useState(1);
  const [cabin, setCabin] = useState("economy");
  const [maxStops, setMaxStops] = useState(2);
  const [sortBy, setSortBy] = useState("price");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [mode, setMode] = useState<"demo"|"live">("demo");
  const [backendUrl, setBackendUrl] = useState("");
  const [provider, setProvider] = useState("amadeus");

  useEffect(()=>{
    try { localStorage.setItem('fpb_prefs', JSON.stringify({ origin, destination, anywhere, adults, cabin, backendUrl, provider, mode })); } catch {}
  }, [origin, destination, anywhere, adults, cabin, backendUrl, provider, mode]);
  useEffect(()=>{
    try { const raw = localStorage.getItem('fpb_prefs'); if (raw) { const p = JSON.parse(raw);
      setOrigin(p.origin || "SSA"); setDestination(p.destination || "LIS"); setAnywhere(!!p.anywhere);
      setAdults(p.adults || 1); setCabin(p.cabin || "economy"); setBackendUrl(p.backendUrl || "");
      setProvider(p.provider || "amadeus"); setMode(p.mode || "demo");
    } } catch {}
  }, []);

  const airportsOptions = useMemo(()=> BR_AIRPORTS.map(a=>({ value:a.code, label:`${a.code} — ${a.city}` })), []);
  const destOptions = useMemo(()=> [{ value: "anywhere", label: "Qualquer lugar" }, ...POP_DESTS.map(a=>({ value:a.code, label:`${a.code} — ${a.city}` }))], []);

  async function search() {
    setLoading(true);
    try {
      if (mode === "demo" || !backendUrl) {
        const dests = anywhere ? POP_DESTS.map(d=>d.code) : [destination];
        const aggregated = dests.flatMap((d)=> generateMockOffers({ origin, destination: d, date, adults, cabin }).map(o=> ({...o, dest: d})));
        const filtered = aggregated.filter((o:any)=> (o.itineraries?.[0]?.segments.length || 1) - 1 <= maxStops);
        const sorted = [...filtered].sort((a:any,b:any)=> sortBy==='price'? a.total-b.total : a.itineraries[0].durationHrs - b.itineraries[0].durationHrs);
        setResults(sorted);
      } else {
        const url = new URL(backendUrl);
        url.searchParams.set('provider', provider);
        url.searchParams.set('origin', origin);
        if (!anywhere) url.searchParams.set('destination', destination);
        url.searchParams.set('date', date);
        url.searchParams.set('adults', String(adults));
        url.searchParams.set('cabin', cabin);
        if (anywhere) url.searchParams.set('everywhere', '1');
        const res = await fetch(url.toString(), { cache: 'no-store' });
        if (!res.ok) throw new Error(`Erro ${res.status}`);
        const json = await res.json();
        const offers = (json.offers || json.data || []).map((o:any) => ({
          id: o.id || o.offerId || Math.random().toString(36).slice(2),
          total: Number(o.total || o.price?.grandTotal || o.price),
          currency: o.currency || o.price?.currency || 'BRL',
          bagIncluded: Boolean(o.bagIncluded || o.includesBag),
          dest: json.destination || o.dest || (o.itineraries?.[0]?.segments?.slice(-1)[0]?.to) || destination,
          itineraries: o.itineraries || [{ durationHrs: o.durationHrs || 0, segments: o.segments || [] }]
        }));
        const filtered = offers.filter((o:any)=> (o.itineraries?.[0]?.segments?.length ?? 1) - 1 <= maxStops);
        const sorted = [...filtered].sort((a:any,b:any)=> sortBy==='price'? a.total-b.total : (a.itineraries?.[0]?.durationHrs||0)-(b.itineraries?.[0]?.durationHrs||0));
        setResults(sorted);
      }
    } catch (e) {
      console.error(e);
      alert('Falha ao buscar preços. Verifique o endpoint no modo Live. Voltando ao modo Demo.');
      setMode('demo');
    } finally {
      setLoading(false);
    }
  }

  const matrixDates = [-3,-2,-1,0,1,2,3].map(d => addDays(date, d));

  useEffect(()=>{ search(); }, []);

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-blue-50 to-white text-gray-800">
      <div className="max-w-6xl mx-auto p-4 sm:p-6">
        <header className="flex items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-2xl bg-blue-600 text-white grid place-items-center shadow"><Plane size={20} /></div>
            <div>
              <h1 className="text-xl sm:text-2xl font-semibold">Buscador de Passagens • Brasil → Mundo</h1>
              <p className="text-sm text-gray-500">Demo local ou Live via seu backend. Preços em BRL.</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2 font-medium shadow-sm border border-gray-200 hover:shadow transition bg-white" onClick={()=> setShowSettings(true)}><Settings size={16}/>Configurações</button>
          </div>
        </header>

        <div className="rounded-2xl shadow-sm border border-gray-200 bg-white mb-6">
          <div className="p-4 sm:p-5 border-b border-gray-100">
            <div className="grid md:grid-cols-12 gap-3 items-end">
              <div className="md:col-span-2">
                <label className="text-xs font-medium text-gray-500">Origem</label>
                <Select value={origin} onChange={(e:any)=> setOrigin(e.target.value)} options={airportsOptions} />
              </div>
              <div className="md:col-span-3">
                <label className="text-xs font-medium text-gray-500 flex items-center justify-between">
                  <span>Destino</span>
                  <span className="inline-flex items-center gap-1 text-[11px] text-blue-700 cursor-pointer" onClick={()=> setAnywhere((v:boolean)=>!v)}><Shuffle size={12}/> {anywhere ? 'Qualquer lugar ✓' : 'Qualquer lugar?'}</span>
                </label>
                <Select value={anywhere ? 'anywhere' : destination} onChange={(e:any)=> { const v=e.target.value; if (v==='anywhere') setAnywhere(true); else { setAnywhere(false); setDestination(v); } }} options={[{ value: "anywhere", label: "Qualquer lugar" }, ...POP_DESTS.map(a=>({ value:a.code, label:`${a.code} — ${a.city}` }))]} />
              </div>
              <div className="md:col-span-2">
                <label className="text-xs font-medium text-gray-500">Data (partida)</label>
                <Input type="date" value={date} onChange={(e:any)=> setDate(e.target.value)} />
              </div>
              <div className="md:col-span-2">
                <label className="text-xs font-medium text-gray-500">Passageiros</label>
                <Input type="number" min={1} max={9} value={adults} onChange={(e:any)=> setAdults(parseInt(e.target.value||'1'))} />
              </div>
              <div className="md:col-span-2">
                <label className="text-xs font-medium text-gray-500">Cabine</label>
                <Select value={cabin} onChange={(e:any)=> setCabin(e.target.value)} options={[
                  {value:'economy', label:'Preço baixo (Econômica)'},
                  {value:'premium_economy', label:'Econômica Premium'},
                  {value:'business', label:'Executiva'},
                  {value:'first', label:'Primeira'}
                ]} />
              </div>
              <div className="md:col-span-1">
                <button onClick={search} className="inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2 font-medium shadow-sm border border-gray-200 hover:shadow transition bg-blue-600 text-white w-full"><Search size={16}/>Buscar</button>
              </div>
            </div>
          </div>
          <div className="p-4 sm:p-5">
            <div className="grid sm:grid-cols-4 gap-3">
              <div className="col-span-2 flex items-center gap-2">
                <Filter size={16}/>
                <label className="text-sm">Máx. escalas:</label>
                <Select value={String(maxStops)} onChange={(e:any)=> setMaxStops(parseInt(e.target.value))} options={[0,1,2].map(n=>({ value:String(n), label: n===0? 'Direto' : `${n}` }))} />
              </div>
              <div className="col-span-2 flex items-center gap-2">
                <Hash size={16}/>
                <label className="text-sm">Ordenar por:</label>
                <Select value={sortBy} onChange={(e:any)=> setSortBy(e.target.value)} options={[{value:'price', label:'Preço'}, {value:'duration', label:'Duração'}]} />
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-2xl shadow-sm border border-gray-200 bg-white mb-6">
          <div className="p-4 sm:p-5 border-b border-gray-100">
            <div className="flex items-center gap-2 text-sm text-gray-600"><Calendar size={16}/> Verifique datas próximas (±3 dias)</div>
          </div>
          <div className="p-4 sm:p-5">
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
              {[-3,-2,-1,0,1,2,3].map((d:number) =>{
                const dt = addDays(date, d);
                const sample = generateMockOffers({ origin, destination: anywhere? POP_DESTS[0].code : destination, date: dt, adults, cabin })[0];
                return (
                  <button key={dt} onClick={()=> setDate(dt)} className={`rounded-xl border px-3 py-2 text-left ${dt===date? 'border-blue-500 bg-blue-50' : 'border-gray-200 bg-white hover:bg-gray-50'}`}>
                    <div className="text-xs text-gray-500">{new Date(dt).toLocaleDateString('pt-BR', { weekday:'short', day:'2-digit', month:'2-digit' })}</div>
                    <div className="font-semibold">{formatBRL(sample.total)}</div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between mb-2">
          <div className="text-sm text-gray-600 flex items-center gap-2"><MapPin size={14}/> {origin} → {anywhere ? 'Qualquer lugar' : destination} • {new Date(date).toLocaleDateString('pt-BR')} • {adults} adulto(s)</div>
          <div className="text-xs text-gray-500">Modo: <strong className="ml-1">{mode === 'demo' ? 'Demo (mock)' : 'Live'}</strong></div>
        </div>

        <div className="rounded-2xl border border-gray-200 bg-white">
          <div className="p-4 sm:p-5">
            <AnimatePresence initial={false}>
              {loading ? (
                <motion.div key="loading" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="grid gap-3">
                  {Array.from({length:5}).map((_,i)=> (<div key={i} className="animate-pulse h-20 rounded-xl bg-gray-100" />))}
                </motion.div>
              ) : (
                <motion.div key="results" initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} exit={{opacity:0}} className="grid gap-3">
                  {results.length === 0 ? (
                    <div className="text-center text-gray-500 py-10">Nenhuma oferta encontrada com os filtros atuais.</div>
                  ) : (
                    results.map((o:any)=> (
                      <div key={o.id + (o.dest||'')} className="rounded-2xl border border-gray-200 p-4 hover:shadow-sm transition">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-xl bg-blue-600 text-white grid place-items-center"><Plane size={18}/></div>
                            <div>
                              <div className="font-semibold text-lg">{origin} <ArrowRight className="inline-block mx-1" size={16}/> {o.dest || (anywhere? '??' : destination)}</div>
                              <div className="text-sm text-gray-500 flex items-center gap-2"><Clock size={14}/> ~{o.itineraries[0].durationHrs}h • {o.itineraries[0].segments.length-1} escala(s)</div>
                              <div className="text-xs text-gray-500">{o.itineraries[0].segments.map((s:any)=> `${s.carrier}${s.flight} ${s.from}→${s.to}`).join(' · ')}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold">{formatBRL(o.total)}</div>
                            <div className="text-xs text-gray-500 flex items-center gap-1 justify-end">{o.bagIncluded && <Luggage size={12}/>} {o.bagIncluded ? '1ª mala incluída' : 'Somente mão'}</div>
                            <div className="mt-2 flex gap-2 justify-end">
                              <button className="inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2 font-medium shadow-sm border border-gray-200 hover:shadow transition bg-blue-600 text-white" onClick={()=> alert('No modo Live, direcione para checkout/cia aérea.') }>Selecionar</button>
                              <button className="inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2 font-medium shadow-sm border border-gray-200 hover:shadow transition" onClick={()=> alert('Crie deep-link para o provedor escolhido (Amadeus/Kiwi).')}>Detalhes</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <AnimatePresence>
          {showSettings && (<motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="fixed inset-0 bg-black/30 z-40" onClick={()=> setShowSettings(false)} />)}
        </AnimatePresence>
        <AnimatePresence>
          {showSettings && (
            <motion.div initial={{x:400}} animate={{x:0}} exit={{x:400}} transition={{type:'spring', stiffness:220, damping:26}} className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-50 shadow-2xl p-6 overflow-auto">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2"><Settings size={18}/> Configurações</h2>
                <button className="inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2 font-medium shadow-sm border border-gray-200 hover:shadow transition" onClick={()=> setShowSettings(false)}>Fechar</button>
              </div>
              <div className="space-y-4 text-sm">
                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
                  <p className="font-medium">Modo de execução</p>
                  <div className="mt-2 flex gap-2">
                    <button className={mode==='demo'? 'bg-blue-600 text-white rounded-2xl px-3 py-1.5' : 'rounded-2xl px-3 py-1.5 border'} onClick={()=> setMode('demo')}>Demo (mock)</button>
                    <button className={mode==='live'? 'bg-blue-600 text-white rounded-2xl px-3 py-1.5' : 'rounded-2xl px-3 py-1.5 border'} onClick={()=> setMode('live')}>Live (requer backend)</button>
                  </div>
                  <label className="block mt-3">
                    <span className="text-xs text-gray-500">Endpoint do backend (/api/search)</span>
                    <Input placeholder="https://seuapp.vercel.app/api/search" value={backendUrl} onChange={(e:any)=> setBackendUrl(e.target.value)} disabled={mode!=='live'} />
                    <span className="text-[11px] text-blue-900">Habilite Live, cole o endpoint e clique em Buscar.</span>
                  </label>
                  <label className="block mt-2">
                    <span className="text-xs text-gray-500">Provedor</span>
                    <Select value={provider} onChange={(e:any)=> setProvider(e.target.value)} options={[{value:'amadeus', label:'Amadeus (recomendado)'},{value:'tequila', label:'Kiwi Tequila (\"Qualquer lugar\")'}]} />
                  </label>
                </div>
                <div>
                  <p className="font-medium mb-2">Como ativar o modo Live</p>
                  <ol className="list-decimal ml-4 mt-2 space-y-1 text-gray-600">
                    <li>Defina o backend conforme <code>/app/api/search/route.ts</code>.</li>
                    <li>Publique (Vercel) e cole o endpoint acima.</li>
                    <li>Busque! Os resultados virão em BRL.</li>
                  </ol>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <footer className="mt-8 text-xs text-gray-500 text-center">
          Feito para o Brasil. Demonstração local; conecte um backend para preços reais.
        </footer>
      </div>
    </div>
  );
}
