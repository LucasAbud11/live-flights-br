export const runtime = 'edge';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const provider = searchParams.get('provider') || 'amadeus'; // 'amadeus' | 'tequila'
  const origin = searchParams.get('origin') || 'GRU';
  const destination = searchParams.get('destination') || '';
  const date = searchParams.get('date') || '';              // YYYY-MM-DD
  const adults = searchParams.get('adults') || '1';
  const cabin = (searchParams.get('cabin') || 'economy').toLowerCase();
  const everywhere = searchParams.get('everywhere') === '1';

  function json(body: any, status = 200) {
    return new Response(JSON.stringify(body), {
      status,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'access-control-allow-origin': '*',
        'cache-control': 'no-store'
      }
    });
  }

  if (!date) return json({ error: 'Missing date' }, 400);
  if (!everywhere && !destination) return json({ error: 'Missing destination' }, 400);

  try {
    if (provider === 'amadeus' && !everywhere) {
      const key = process.env.AMADEUS_KEY!;
      const secret = process.env.AMADEUS_SECRET!;
      if (!key || !secret) return json({ error: 'Amadeus not configured' }, 500);

      const tokenRes = await fetch('https://api.amadeus.com/v1/security/oauth2/token', {
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          grant_type: 'client_credentials',
          client_id: key,
          client_secret: secret,
        })
      });
      if (!tokenRes.ok) return json({ error: 'amadeus_oauth_failed' }, 502);
      const { access_token } = await tokenRes.json();

      const url = new URL('https://api.amadeus.com/v2/shopping/flight-offers');
      url.searchParams.set('originLocationCode', origin);
      url.searchParams.set('destinationLocationCode', destination);
      url.searchParams.set('departureDate', date);
      url.searchParams.set('adults', adults);
      url.searchParams.set('currencyCode', 'BRL');
      url.searchParams.set('max', '50');
      if (['premium_economy','business','first'].includes(cabin)) {
        url.searchParams.set('travelClass', cabin.replace('_','').toUpperCase());
      }

      const res = await fetch(url.toString(), { headers: { Authorization: `Bearer ${access_token}` } });
      if (!res.ok) return json({ error: 'amadeus_search_failed', status: res.status }, 502);
      const data = await res.json();

      const offers = (data?.data || []).map((o: any) => ({
        id: o.id,
        total: Number(o.price?.grandTotal),
        currency: o.price?.currency || 'BRL',
        bagIncluded: Boolean(o.travelerPricings?.[0]?.fareDetailsBySegment?.some((f:any)=> f.includedCheckedBags?.quantity > 0)),
        itineraries: (o.itineraries || []).map((it: any) => ({
          durationHrs: parseISODurationToHours(it.duration),
          segments: (it.segments || []).map((s: any) => ({
            carrier: s.carrierCode, flight: s.number,
            from: s.departure?.iataCode, to: s.arrival?.iataCode,
            dep: s.departure?.at, arr: s.arrival?.at
          }))
        }))
      }));
      return json({ provider, origin, destination, date, adults, offers });
    }

    if (provider === 'tequila') {
      const key = process.env.TEQUILA_KEY!;
      if (!key) return json({ error: 'Tequila not configured' }, 500);

      const url = new URL('https://api.tequila.kiwi.com/v2/search');
      url.searchParams.set('fly_from', origin);
      url.searchParams.set('curr', 'BRL');
      url.searchParams.set('limit', '50');
      if (everywhere) url.searchParams.set('fly_to', 'anywhere');
      else url.searchParams.set('fly_to', destination);

      const [y,m,d] = date.split('-');
      url.searchParams.set('date_from', `${d}/${m}/${y}`);
      url.searchParams.set('date_to', `${d}/${m}/${y}`);
      url.searchParams.set('adults', adults);

      const res = await fetch(url.toString(), { headers: { apikey: key } });
      if (!res.ok) return json({ error: 'tequila_search_failed', status: res.status }, 502);
      const out = await res.json();

      const offers = (out?.data || []).map((o: any) => ({
        id: o.id,
        total: Number(o.price),
        currency: out?.currency || 'BRL',
        bagIncluded: Boolean(o.bags_price && Object.values(o.bags_price).some((v:any)=> Number(v) == 0)),
        dest: o.cityCodeTo || o.flyTo,
        itineraries: [{
          durationHrs: Math.round(((o.duration?.total || 0) / 3600)),
          segments: (o.route || []).map((s: any) => ({
            carrier: s.airline, flight: String(s.flight_no),
            from: s.flyFrom, to: s.flyTo,
            dep: s.utc_departure, arr: s.utc_arrival
          }))
        }]
      }));
      return json({ provider, origin, destination: everywhere ? 'anywhere' : destination, date, adults, offers });
    }

    return json({ error: 'Unsupported provider or params' }, 400);
  } catch (e: any) {
    return json({ error: 'internal', message: e?.message || String(e) }, 500);
  }
}

function parseISODurationToHours(iso: string) {
  const m = /PT(?:(\d+)H)?(?:(\d+)M)?/.exec(iso || '') || [];
  const h = Number(m[1] || 0), min = Number(m[2] || 0);
  return Math.round(h + min/60);
}
