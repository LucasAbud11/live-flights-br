import FlightPriceFinderBR from "@/components/FlightPriceFinderBR";
export default function Page() { return <FlightPriceFinderBR />; }
