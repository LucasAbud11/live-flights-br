# Live Flights BR — Next.js (frontend + backend)

Run locally:
```bash
npm install
npm run dev
```

Deploy to Vercel and set env vars:
- AMADEUS_KEY
- AMADEUS_SECRET
- TEQUILA_KEY
